import json
import azure.functions as func
from typing import List, Dict

class UserResource:
    def __init__(self):
        self.name = None
        self.type = None
        self.id = None
        self.properties = None

class User:
    def __init__(self):
        self.FullName = None
        self.Location = None

separator = ":::"

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

@app.route(route="ChMongoCluster")
def ChMongoCluster(req: func.HttpRequest, subscriptionId: str, resourceGroupName: str, miniRpName: str, action: str, instorageBlob: str, name: str = None) -> func.HttpResponse:
    response = None
    outstorageBlob = instorageBlob

    if name == "{name}":
        name = None

    if action == "users":
        callmethod = req.method
        user_info = get_user_dictionary_from_file(instorageBlob)

        if name is None and callmethod != "GET":
            return func.HttpResponse("Method Not Allowed", status_code=405)

        id = req.url.lower().replace("/api", "")

        if callmethod == "PUT":
            body_string = req.get_body().decode("utf-8")
            user_json = json.loads(body_string)
            input_object = json.loads(user_json, object_hook=lambda d: UserResource(**d))
            input_object.id = id
            input_object.name = name
            input_object.type = "Microsoft.CustomProviders/resourceproviders/users"

            if id in user_info:
                user_info[id] = input_object
                response = func.HttpResponse(json.dumps(input_object), status_code=200, mimetype="application/json")
            else:
                user_info[id] = input_object
                response = func.HttpResponse(json.dumps(input_object), status_code=201, mimetype="application/json")

        elif callmethod == "GET":
            if name is None:
                response = func.HttpResponse(json.dumps(user_info), status_code=200, mimetype="application/json")
            else:
                if id in user_info:
                    response = func.HttpResponse(json.dumps(user_info[id]), status_code=200, mimetype="application/json")
                else:
                    response = func.HttpResponse("User not found", status_code=404)

        elif callmethod == "DELETE":
            if id in user_info:
                deleted_user = user_info.pop(id)
                response = func.HttpResponse(json.dumps(deleted_user), status_code=200, mimetype="application/json")
            else:
                response = func.HttpResponse("User not found", status_code=404)
        else:
            return func.HttpResponse("Method Not Allowed", status_code=405)

        outstorageBlob = save_user_dictionary(user_info)

    return response

def get_user_dictionary_from_file(storage_blob: str) -> Dict[str, UserResource]:
    dictionary = {}

    if not storage_blob:
        return dictionary

    users = storage_blob.split(separator)
    for user in users:
        data = user.split(",")
        if len(data) == 5:
            user_resource = UserResource()
            user_resource.name = data[0]
            user_resource.type = data[1]
            user_resource.id = data[2]
            user_resource.properties = User()
            user_resource.properties.FullName = data[3]
            user_resource.properties.Location = data[4]
            dictionary[data[2]] = user_resource

    return dictionary

def save_user_dictionary(user_dictionary: Dict[str, UserResource]) -> str:
    storage_blob = ""
    for user_id, user_resource in user_dictionary.items():
        data = get_save_format(user_resource)
        storage_blob += data + separator
    return storage_blob

def get_save_format(user_resource: UserResource) -> str:
    return f"{user_resource.name},{user_resource.type},{user_resource.id},{user_resource.properties.FullName},{user_resource.properties.Location}"
