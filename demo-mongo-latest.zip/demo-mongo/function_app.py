import azure.functions as func
import logging

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

@app.route(route="ChMongoCluster")
def ChMongoCluster(req: func.HttpRequest, subscriptionId: str, resourceGroupName: str, miniRpName: str, action: str, instorageBlob: str, name: str, outstorageBlob: str) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    if name == "{name}":
        name = None

    if action == "users":
        callmethod = req.method

        if callmethod == "GET":
           logging.info('Method Get Performed')
           return func.HttpResponse("Method Get Performed", status_code=200)

        if callmethod == "PUT":
           logging.info('Method PUT Performed')
           return func.HttpResponse("Method PUT Performed", status_code=200)

        if callmethod == "DELETE":
           logging.info('Method DELETE Performed')
           return func.HttpResponse("Method DELETE Performed", status_code=200)

        if callmethod == "POST":
           logging.info('Method POST Performed')
           return func.HttpResponse("Method POST Performed", status_code=200)

    if action == "ping":
        callmethod = req.method

        if callmethod == "POST":
           logging.info('Method POST Performed with action ping')
           return func.HttpResponse("Method POST Performed", status_code=200)

    return func.HttpResponse("Action users not Performed", status_code=200)
