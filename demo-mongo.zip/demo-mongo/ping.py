import azure.functions as func
import json

def main(req: func.HttpRequest, subscriptionId: str, resourceGroupName: str, miniRpName: str, action: str) -> func.HttpResponse:
    if action == "ping":
        if req.method != "POST":
            return func.HttpResponse("Method not allowed", status_code=405)
        else:
            host = req.headers.get('Host', 'anonymous')
            content = {
                'pingcontent': {
                    'source': host
                },
                'message': f'hello {host}'
            }
            return func.HttpResponse(json.dumps(content), status_code=200, mimetype='application/json')
    else:
        return func.HttpResponse("Invalid action", status_code=400)
