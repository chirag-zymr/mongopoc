import logging
import json

import azure.functions as func


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    name = req.params.get('name')
    if not name:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            name = req_body.get('name')
            
    logging.info('Mongo atlas project creation api')                
    logging.info(f'Mongo atlas project creation api with received params {name}')      
    try:
        data = {"message": "This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response."}
        json_data = json.dumps(data)
        if name:
            return func.HttpResponse(f"Hello, {name}. This HTTP triggered function executed successfully.")
        else:
            return func.HttpResponse(
                json_data,
                status_code=200,
                mimetype="application/json"
            )
    except Exception as e:
        logging.error(f'Python HTTP trigger function processed a request. {e}')
        return func.HttpResponse(
                "Internal Server Error",
                status_code=500
            )